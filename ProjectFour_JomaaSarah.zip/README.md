# FinalProject

APIs selected: iTunes, IMDb
Visualization/package tools used: plot.ly

Required libraries: requests, json, sqlite3, plotly

Instructions:
Run the code and follow directions when prompted on screen.